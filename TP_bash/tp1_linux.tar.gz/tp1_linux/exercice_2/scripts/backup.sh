#!/bin/bash
echo "========================================================="
echo "[SUCCÈS] Le script de sauvegarde s'est exécuté sans erreur !"
echo "Tous les instantanés système ont été synchronisés."
echo "========================================================="
